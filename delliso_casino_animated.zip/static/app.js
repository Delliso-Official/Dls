const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }

const $ = (id) => document.getElementById(id);
const state = { balance: 10000, currentGame: "slots", choice: "red", mines: 3, tile: null, busy: false, data: null, toastTimer: null };
const games = {
  slots: { title: "Слоты", icon: "🎰", kicker: "ТРИ БАРАБАНА", desc: "Собери комбинацию символов", options: [] },
  mines: { title: "Mines", icon: "💣", kicker: "РИСК И НАГРАДА", desc: "Открой безопасную клетку", options: [{v:"3",t:"3 мины"},{v:"5",t:"5 мин"},{v:"8",t:"8 мин"}] },
  roulette: { title: "Рулетка", icon: "🎡", kicker: "ВЫБЕРИ ЦВЕТ", desc: "Угадай, куда попадёт шарик", options: [{v:"red",t:"🔴 Красное"},{v:"black",t:"⚫ Чёрное"},{v:"green",t:"🟢 Зелёное"}] },
  wheel: { title: "Колесо фортуны", icon: "🎯", kicker: "КРУТИ УДАЧУ", desc: "Проверь, какой множитель выпадет", options: [] },
  cases: { title: "Кейсы", icon: "🎁", kicker: "ОТКРОЙ КЕЙС", desc: "Внутри может быть сюрприз", options: [] },
  coinflip: { title: "Орёл и решка", icon: "🪙", kicker: "50 НА 50", desc: "Выбери сторону монеты", options: [{v:"heads",t:"🦅 Орёл"},{v:"tails",t:"🌙 Решка"}] }
};
const labels = { slots:"Слоты", mines:"Mines", roulette:"Рулетка", wheel:"Колесо", cases:"Кейсы", coinflip:"Орёл / решка" };
const icons = { slots:"🎰", mines:"💣", roulette:"🎡", wheel:"🎯", cases:"🎁", coinflip:"🪙" };

function telegramHeaders() {
  return { "Content-Type":"application/json", "X-Telegram-Init-Data": tg?.initData || "" };
}
function format(n) { return Number(n || 0).toLocaleString("ru-RU"); }
function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function api(path, options={}) {
  const response = await fetch(path, { ...options, headers: { ...telegramHeaders(), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.detail || "Не удалось выполнить запрос");
  return data;
}
function animateNumber(el, from, to) {
  if (!el) return;
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) { el.textContent = format(to); return; }
  const start = performance.now(), duration = 420;
  function tick(now) {
    const t = Math.min(1, (now - start) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    el.textContent = format(Math.round(from + (to - from) * eased));
    if (t < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
function applyData(data) {
  const previous = Number(state.balance || 0);
  state.data = data; state.balance = data.balance;
  animateNumber($("balance"), previous, data.balance);
  animateNumber($("profileBalance"), previous, data.balance);
  $("gamesPlayed").textContent = format(data.gamesPlayed);
  $("wins").textContent = format(data.wins);
  renderHistory(data.history || []);
}
function renderHistory(history) {
  const list = $("historyList");
  if (!history.length) { list.innerHTML = '<p class="empty-state">Пока нет сыгранных раундов</p>'; return; }
  list.innerHTML = history.map(row => {
    const delta = Number(row.delta);
    return `<div class="history-row"><span class="history-emoji">${icons[row.game] || "🎮"}</span><div class="history-info"><b>${labels[row.game] || row.game}</b><small>${escapeHtml(row.result || "")} · ставка ${format(row.bet)}</small></div><span class="history-delta ${delta >= 0 ? "positive" : "negative"}">${delta > 0 ? "+" : ""}${format(delta)}</span></div>`;
  }).join("");
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
async function refresh() {
  try { applyData(await api("/api/me")); }
  catch { toast("Не удалось загрузить профиль. Обнови страницу."); }
}
function showScreen(name) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  $(name + "Screen").classList.add("active");
  document.querySelectorAll(".nav-item").forEach(n => n.classList.toggle("selected", n.dataset.tab === (name === "profile" ? "profile" : name === "game" ? "games" : "home")));
  window.scrollTo({top:0, behavior:"smooth"});
}
function openGame(key) {
  const game = games[key]; if (!game) return;
  state.currentGame = key; state.choice = key === "coinflip" ? "heads" : "red"; state.mines = 3; state.tile = null;
  $("minesBoard").hidden = key !== "mines";
  $("minesBoard").innerHTML = "";
  $("animationStage").className = "animation-stage";
  $("gameTitle").textContent = game.title; $("gameTitleIcon").textContent = game.icon; $("gameKicker").textContent = game.kicker;
  $("resultDisplay").innerHTML = `<span class="result-icon">${game.icon}</span><strong>${game.title}</strong><small>${game.desc}</small>`;
  $("gameOptions").innerHTML = game.options.map((o,i) => `<button class="option-btn ${i===0?"active":""}" data-choice="${o.v}">${o.t}</button>`).join("");
  $("gameOptions").querySelectorAll("[data-choice]").forEach(btn => btn.addEventListener("click", () => {
    state.choice = btn.dataset.choice;
    if (key === "mines") { state.mines = Number(btn.dataset.choice); state.tile = null; buildMinesBoard(); }
    $("gameOptions").querySelectorAll(".option-btn").forEach(b => b.classList.toggle("active", b === btn));
  }));
  if (key === "mines") buildMinesBoard();
  $("betInput").value = 100; showScreen("game");
}
function buildMinesBoard(revealed = null) {
  const board = $("minesBoard");
  if (state.currentGame !== "mines") return;
  board.hidden = false;
  board.innerHTML = Array.from({length:25}, (_, i) => {
    const isMine = revealed && revealed.minePositions?.includes(i);
    const isSelected = revealed && revealed.selectedTile === i;
    let cls = "mine-tile";
    let icon = "✦";
    if (revealed) { cls += " revealed"; icon = isMine ? "💣" : "💎"; if (isSelected) cls += isMine ? " hit" : " safe"; }
    else if (state.tile === i) cls += " selected";
    return `<button type="button" class="${cls}" data-tile="${i}" ${revealed || state.busy ? "disabled" : ""} aria-label="Клетка ${i+1}">${icon}</button>`;
  }).join("");
  if (!revealed) board.querySelectorAll("[data-tile]").forEach(btn => btn.addEventListener("click", () => {
    state.tile = Number(btn.dataset.tile);
    board.querySelectorAll(".mine-tile").forEach(tile => tile.classList.toggle("selected", tile === btn));
    $("resultDisplay").innerHTML = `<span class="result-icon">💎</span><strong>Клетка ${state.tile + 1} выбрана</strong><small>Нажми «Играть», чтобы проверить её. Результат определяет сервер.</small>`;
  }));
}
function animateGameStart(game) {
  const stage = $("animationStage");
  stage.className = "animation-stage active " + game;
  stage.innerHTML = game === "slots" ? '<div class="slot-reels"><span>🍒</span><span>⭐</span><span>🔔</span></div>' :
    game === "roulette" ? '<div class="roulette-spin">🎡</div>' :
    game === "wheel" ? '<div class="wheel-spin">🎯</div>' :
    game === "cases" ? '<div class="case-spin">🎁</div>' :
    game === "coinflip" ? '<div class="coin-spin">🪙</div>' : '';
  if (game === "mines") $("minesBoard").classList.add("board-playing");
}
function finishGameAnimation(data) {
  const stage = $("animationStage");
  stage.classList.remove("active");
  if (data.game === "mines") buildMinesBoard({selectedTile:data.selectedTile, minePositions:data.minePositions});
  document.querySelector(".game-board")?.classList.toggle("win-pulse", Number(data.delta) > 0);
  setTimeout(() => document.querySelector(".game-board")?.classList.remove("win-pulse"), 1000);
  if (Number(data.delta) > 0 && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const board = document.querySelector(".game-board");
    for (let i=0;i<12;i++) {
      const coin=document.createElement("span"); coin.className="coin-particle"; coin.textContent="🪙";
      coin.style.setProperty("--x", `${Math.round(Math.random()*220-110)}px`);
      coin.style.setProperty("--delay", `${Math.random()*180}ms`);
      board.appendChild(coin); setTimeout(()=>coin.remove(), 1100);
    }
  }
}
document.querySelectorAll("[data-game]").forEach(btn => btn.addEventListener("click", () => openGame(btn.dataset.game)));
$("backBtn").addEventListener("click", () => showScreen("home"));
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => {
  if (btn.dataset.tab === "profile") { showScreen("profile"); refresh(); }
  else if (btn.dataset.tab === "games") showScreen("home");
  else showScreen("home");
}));
$("betMinus").addEventListener("click", () => $("betInput").value = Math.max(1, (Number($("betInput").value)||1)-50));
$("betPlus").addEventListener("click", () => $("betInput").value = Math.min(1000000, (Number($("betInput").value)||0)+50));
document.querySelectorAll("[data-bet]").forEach(btn => btn.addEventListener("click", () => {
  $("betInput").value = btn.dataset.bet === "max" ? Math.max(1,state.balance) : btn.dataset.bet;
}));
$("bonusBtn").addEventListener("click", async () => {
  $("bonusBtn").disabled = true;
  try { const data = await api("/api/bonus", {method:"POST"}); applyData(data); toast(`Бонус +${format(data.bonus)} виртуальных монет!`); }
  catch (e) { toast(e.message); }
  finally { $("bonusBtn").disabled = false; }
});
$("playBtn").addEventListener("click", async () => {
  if (state.busy) return;
  if (state.currentGame === "mines" && state.tile === null) { toast("Сначала выбери клетку на поле"); return; }
  const bet = Math.floor(Number($("betInput").value));
  if (!Number.isFinite(bet) || bet < 1) { toast("Укажи ставку от 1 монеты"); return; }
  if (bet > state.balance) { toast("Недостаточно виртуальных монет"); return; }
  state.busy = true;
  const button = $("playBtn"); button.disabled = true; button.innerHTML = "Играем… <span>✦</span>";
  $("gameOptions").querySelectorAll("button").forEach(b => b.disabled = true);
  animateGameStart(state.currentGame);
  try {
    const payload = { bet, choice: state.choice, mines: state.mines, tile: state.tile };
    const data = await api(`/api/play/${state.currentGame}`, {method:"POST", body:JSON.stringify(payload)});
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!reduced) await new Promise(resolve => setTimeout(resolve, state.currentGame === "mines" ? 500 : 950));
    applyData(data);
    finishGameAnimation(data);
    const won = data.delta > 0;
    $("resultDisplay").innerHTML = `<span class="result-icon">${won ? "🎉" : data.delta === 0 ? "🤝" : "💫"}</span><strong>${escapeHtml(data.result)}</strong><small>${won ? `Выигрыш: +${format(data.delta)} монет` : data.delta === 0 ? "Ставка возвращена" : `Изменение баланса: −${format(Math.abs(data.delta))} монет`}</small>`;
    toast(won ? "Поздравляем с выигрышем!" : "Раунд завершён");
  } catch(e) { toast(e.message); }
  finally {
    state.busy = false;
    button.disabled = false; button.innerHTML = 'Играть <span>↗</span>';
    $("gameOptions").querySelectorAll("button").forEach(b => b.disabled = false);
    if (state.currentGame === "mines" && !$("minesBoard").querySelector(".revealed")) buildMinesBoard();
  }
});
refresh();
