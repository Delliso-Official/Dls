import asyncio
import hashlib
import hmac
import json
import os
import random
import sqlite3
import time
from datetime import date
from pathlib import Path
from urllib.parse import parse_qsl

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
MINI_APP_URL = os.getenv("MINI_APP_URL", "").strip()
DB_PATH = Path("casino.db")
STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Delliso Casino")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

STARTING_BALANCE = 10_000
DAILY_BONUS = 1_000
GAMES = {"slots", "mines", "roulette", "wheel", "cases", "coinflip"}


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                balance INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                last_bonus TEXT,
                games_played INTEGER NOT NULL DEFAULT 0,
                wins INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                game TEXT NOT NULL,
                bet INTEGER NOT NULL,
                delta INTEGER NOT NULL,
                result TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)


init_db()


def validate_telegram_init_data(init_data: str):
    """Validate Telegram WebApp initData using the official HMAC scheme."""
    if not BOT_TOKEN or not init_data:
        return None
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash", None)
        if not received_hash:
            return None
        data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            return None
        user = json.loads(pairs.get("user", "{}"))
        if not user.get("id"):
            return None
        return str(user["id"])
    except Exception:
        return None


def user_id_from_request(request: Request):
    init_data = request.headers.get("X-Telegram-Init-Data", "")
    telegram_id = validate_telegram_init_data(init_data)
    if telegram_id:
        return telegram_id
    # Demo mode is intentionally available until a valid Telegram initData is provided.
    return "demo-user"


def get_or_create_user(user_id: str):
    today = date.today().isoformat()
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO users(user_id,balance,created_at) VALUES(?,?,?)",
                (user_id, STARTING_BALANCE, today),
            )
            row = conn.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
    return dict(row)


def public_user(user_id: str):
    user = get_or_create_user(user_id)
    with db() as conn:
        recent = conn.execute(
            "SELECT game,bet,delta,result,created_at FROM history WHERE user_id=? ORDER BY id DESC LIMIT 8",
            (user_id,),
        ).fetchall()
    return {
        "balance": user["balance"],
        "gamesPlayed": user["games_played"],
        "wins": user["wins"],
        "lastBonus": user["last_bonus"],
        "history": [dict(r) for r in recent],
        "demoMode": user_id == "demo-user",
    }


class BetRequest(BaseModel):
    bet: int = Field(ge=1, le=1_000_000)
    choice: str | None = None
    mines: int | None = Field(default=3, ge=1, le=20)
    tile: int | None = Field(default=None, ge=0, le=24)


@app.get("/")
async def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/me")
async def me(request: Request):
    user_id = user_id_from_request(request)
    return public_user(user_id)


@app.post("/api/bonus")
async def bonus(request: Request):
    user_id = user_id_from_request(request)
    today = date.today().isoformat()
    get_or_create_user(user_id)
    with db() as conn:
        row = conn.execute("SELECT balance,last_bonus FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row["last_bonus"] == today:
            raise HTTPException(status_code=400, detail="Ежедневный бонус уже получен. Возвращайся завтра!")
        conn.execute("UPDATE users SET balance=balance+?,last_bonus=? WHERE user_id=?",
                     (DAILY_BONUS, today, user_id))
    return {"ok": True, "bonus": DAILY_BONUS, **public_user(user_id)}


@app.post("/api/play/{game}")
async def play(game: str, payload: BetRequest, request: Request):
    if game not in GAMES:
        raise HTTPException(status_code=404, detail="Неизвестная игра")
    user_id = user_id_from_request(request)
    user = get_or_create_user(user_id)
    bet = payload.bet
    if bet > user["balance"]:
        raise HTTPException(status_code=400, detail="Недостаточно виртуальных монет")

    # Outcome generation happens on the server, not in the browser.
    label = ""
    payout = 0

    if game == "slots":
        symbols = ["🍒", "🍋", "🔔", "⭐", "💎", "7️⃣"]
        reels = [random.choice(symbols) for _ in range(3)]
        label = "  ".join(reels)
        if reels[0] == reels[1] == reels[2]:
            payout = bet * (8 if reels[0] == "7️⃣" else 5)
        elif len(set(reels)) == 2:
            payout = bet * 2
    elif game == "mines":
        mine_count = payload.mines or 3
        if payload.tile is None:
            raise HTTPException(status_code=400, detail="Сначала выбери клетку на поле")
        # The backend generates mine positions and determines the selected tile's outcome.
        mine_positions = set(random.sample(range(25), min(mine_count, 24)))
        win = payload.tile not in mine_positions
        label = "💎 Безопасная клетка!" if win else "💣 Бум! Попалась мина"
        payout = int(bet * 1.8) if win else 0
        # Used only for rendering the authoritative result after the round.
        mine_reveal = sorted(mine_positions)
    elif game == "roulette":
        number = random.randint(0, 36)
        color = "зелёное" if number == 0 else ("красное" if number in {1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36} else "чёрное")
        label = f"Выпало {number} — {color}"
        choice = (payload.choice or "red").lower()
        won = (choice == "red" and color == "красное") or (choice == "black" and color == "чёрное") or (choice == "green" and color == "зелёное")
        payout = bet * (14 if choice == "green" else 2) if won else 0
    elif game == "wheel":
        segments = [("😢", 0), ("🪙 x1.5", 1.5), ("🪙 x2", 2), ("💜 x3", 3), ("🎉 x5", 5), ("😢", 0)]
        name, multiplier = random.choice(segments)
        label = f"Колесо остановилось на {name}"
        payout = int(bet * multiplier)
    elif game == "cases":
        drops = [("🪙 x0", 0), ("🪙 x0.5", 0.5), ("🪙 x1.2", 1.2), ("💎 x2", 2), ("👑 x5", 5)]
        name, multiplier = random.choices(drops, weights=[30, 25, 22, 18, 5], k=1)[0]
        label = f"В кейсе: {name}"
        payout = int(bet * multiplier)
    elif game == "coinflip":
        result = random.choice(["heads", "tails"])
        choice = (payload.choice or "heads").lower()
        label = "Выпал орёл 🦅" if result == "heads" else "Выпала решка 🌙"
        payout = bet * 2 if choice == result else 0

    # Net delta is payout minus stake; payout includes the returned stake.
    delta = payout - bet
    with db() as conn:
        conn.execute(
            "UPDATE users SET balance=balance+?,games_played=games_played+1,wins=wins+? WHERE user_id=?",
            (delta, 1 if payout > bet else 0, user_id),
        )
        conn.execute(
            "INSERT INTO history(user_id,game,bet,delta,result,created_at) VALUES(?,?,?,?,?,?)",
            (user_id, game, bet, delta, label, time.strftime("%Y-%m-%d %H:%M:%S")),
        )
    response_data = {"ok": True, "game": game, "bet": bet, "payout": payout, "delta": delta,
                     "result": label, **public_user(user_id)}
    if game == "mines":
        response_data["selectedTile"] = payload.tile
        response_data["minePositions"] = mine_reveal
    return response_data


async def run_bot():
    if not BOT_TOKEN:
        return
    from aiogram import Bot, Dispatcher
    from aiogram.filters import CommandStart
    from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

    bot = Bot(BOT_TOKEN)
    dp = Dispatcher()

    @dp.message(CommandStart())
    async def start(message: Message):
        if MINI_APP_URL.startswith("https://"):
            keyboard = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="🎰 Открыть Delliso Casino", web_app=WebAppInfo(url=MINI_APP_URL))
            ]])
            await message.answer(
                "Добро пожаловать в Delliso Casino!\nЭто фан-игровой проект с виртуальными монетами без вывода средств.",
                reply_markup=keyboard,
            )
        else:
            await message.answer(
                "Бот создан! Чтобы добавить кнопку Mini App, установи MINI_APP_URL в Secrets на публичный HTTPS-адрес приложения."
            )

    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


@app.on_event("startup")
async def startup_event():
    if BOT_TOKEN:
        app.state.bot_task = asyncio.create_task(run_bot())


@app.on_event("shutdown")
async def shutdown_event():
    task = getattr(app.state, "bot_task", None)
    if task:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


@app.exception_handler(HTTPException)
async def http_error_handler(request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
