# Delliso Casino — starter project

A mobile-first Telegram Mini App prototype with virtual coins only.

## Included
- Six demo games: Slots, Mines, Roulette, Wheel of Fortune, Cases, Heads or Tails
- Virtual balance, daily bonus, profile stats
- FastAPI backend and SQLite database
- Optional Telegram bot with a button that opens the Mini App
- Telegram Mini App `initData` validation when `BOT_TOKEN` is configured
- Demo mode for previewing before Telegram is connected

## Run on Replit
1. Create a new **Python** app in Replit.
2. Upload/extract this project or upload the ZIP and extract its contents into the project.
3. Replit should install packages from `requirements.txt`. If not, open Shell and run:
   `pip install -r requirements.txt`
4. Copy `.env.example` to `.env`.
5. Run the web app with:
   `uvicorn main:app --host 0.0.0.0 --port 3000`
6. Open the web preview.

## Connect the Telegram bot
1. In Replit Secrets, add `BOT_TOKEN` with the token from BotFather.
2. After deployment, copy the public HTTPS app URL and set `MINI_APP_URL` to it.
3. Restart the app. The bot will start polling and provide an `/start` button to open the Mini App.
4. Keep the token secret. Never paste it into chat or frontend JavaScript.

## Notes
- All currency is fictional and cannot be withdrawn or exchanged.
- This is a starter prototype, not a production-ready gambling system.
- The backend controls game outcomes and balance updates; do not trust client-side balance values.
- Before public release, add rate limits, abuse monitoring, backups, and proper deployment secrets.

## Animation and Mines interaction update
- Added animated game-stage effects, balance count-up, win pulse and coin particles.
- Mines now presents a 5×5 board. Choose a specific tile before pressing Play; the backend generates mine positions and determines the selected tile's outcome.
- The animation honors `prefers-reduced-motion`.
- SQLite storage remains local to the deployment by default; choose persistent storage/backups before using this beyond a demo.
